const express = require('express');
const path = require('path');

const app = express();
const PORT = 5000;

app.use(express.static(path.join(__dirname, 'portfolio')));

const downloadableFiles = {
  'index.html': path.join(__dirname, 'portfolio', 'index.html'),
  'style.css': path.join(__dirname, 'portfolio', 'css', 'style.css'),
  'responsive.css': path.join(__dirname, 'portfolio', 'css', 'responsive.css'),
  'main.js': path.join(__dirname, 'portfolio', 'js', 'main.js'),
  'project.zip': path.join(__dirname, 'codefusion-complete-project.zip'),
};

app.get('/download/:file', (req, res) => {
  const filePath = downloadableFiles[req.params.file];
  if (!filePath) {
    return res.status(404).send('File not found');
  }
  res.download(filePath, req.params.file);
});

app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'portfolio', 'index.html'));
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`Codefusion portfolio running on http://0.0.0.0:${PORT}`);
});
